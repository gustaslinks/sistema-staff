EDITE login.js:

const SUPABASE_URL = "COLE_AQUI_PROJECT_URL";
const SUPABASE_ANON_KEY = "COLE_AQUI_PUBLISHABLE_KEY";

Use:
- Project URL
- Publishable Key
